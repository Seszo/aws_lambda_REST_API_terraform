import json
import csv
import boto3
from io import StringIO

def lambda_handler(event, context):
    
    #importing the csv from S3 bucket    
    bucket = "poc-bucket-payout"
    file_name = "titanic.csv"
    s3 = boto3.client('s3') 
    #create connection to S3 using default config and all buckets within S3
    obj = s3.get_object(Bucket= bucket, Key= file_name) 
    # get object and file (key) from bucket
    data = {} #creating a dictionary
    f = StringIO(obj['Body'].read().decode("utf-8"))
    csvReader = csv.DictReader(f)

    for rows in csvReader:
        key = rows['PassengerId']
        data[key] = rows

    return {
        'statusCode': 200,
        'body': json.dumps(data[event["queryStringParameters"]["id"]])

    }

